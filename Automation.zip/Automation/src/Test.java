import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello");
		

	System.setProperty("webdriver.gecko.driver", "C:\\softwares\\geckodriver-v0.29.1-win64\\geckodriver.exe");
	WebDriver driver = new FirefoxDriver();
	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	driver.get("http://mathworks.com");
	driver.manage().window().maximize();
	driver.findElement(By.linkText("India")).click();

		
		/*
	System.setProperty("webdriver.chrome.driver", "C:\\softwares\\chromedriver_win32\\chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	driver.get("http://mathworks.com");
	driver.manage().window().maximize();
	driver.findElement(By.linkText("India")).click();
	
	*/
	
/*
	
	System.setProperty("webdriver.ie.driver", "C:\\softwares\\IEDriverServer_x64_3.150.1\\IEDriverServer.exe");
	WebDriver driver = new InternetExplorerDriver();
	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	driver.get("http://mathworks.com");
	driver.manage().window().maximize();
	driver.findElement(By.linkText("India")).click();
	
	*/
	}

}
