package corejava;

public class MethodOverloading {

	public void getData(int a) {
		System.out.println("Integer a values is : " + a);
	}

	public void getData(int a, int b) {
		System.out.println("Integer a values is : " + a + " Integer b value is : " + b);
	}

	public void getData() {

		System.out.println("No argument");

	}

	public void getData(String str1) {
		System.out.println("String value is : " + str1);
	}
	
	public void getData(String str1, String str2) {
		System.out.println("String 1 value is :" + str1 + " String 2 value is : " + str2);
		
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		MethodOverloading m = new MethodOverloading();
		m.getData();
		m.getData(2021);
		m.getData(1990, 2021);
		m.getData("Hello");
		m.getData("Hello", "World");

	}

}
