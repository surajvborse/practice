package corejava;

public class ParentClass {
	
	
	public ParentClass() {
		System.out.println("Parent class constructor");
	}
	
	String name ="Barclays";
	
	
	public void getData() {
		System.out.println("Parent class getdata");
	}
	
	public void engine() {
		System.out.println("Parent engine");
	}
	
	
	public void brakes() {
		System.out.println("Parent brakes ");
	}
	
	
	public void audiosystem() {
		System.out.println("Parent audiosystem");
	}

}
