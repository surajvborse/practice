package corejava;

public class Arrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	//	int a =5;
		
	int a[] = new int[5];
	
	int b[] = new int[10];
		
	a[0]=2;
	a[1]=4;
	a[2]=6;	
	a[3]=8;
	a[4]=10;

	for(int i=0;i<a.length;i++) {
		System.out.println(a[i]);
	}
	
	int c[] = {1,3,5,7,9,11};
	
	for(int i=0;i<c.length;i++) {
		System.out.println(c[i]);
	}
	
	
	
	//-------------------------
	
	
	String str[] = new String[5];
	str[0]="Hello";
	str[1]="This";
	str[2]="is";
	str[3]="my";
	str[4]="desktop";
	
	for(int i=0;i<str.length;i++) {
		System.out.println(str[i]);
	}
	
	}

}
