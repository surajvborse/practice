package corejava;

public class Constructors {
	
	
	
	//Implicit constuctors - if not defined default constructor used by java
	//Expplicit contructor - user defined
	//no return type can be mentioned
	//return type cannot be expected
	//parameterized construtors
	
	public Constructors() {
		
		int a =1990;
		
		System.out.println(" I am in contructor and value of as is : " +a);
		
	}
	
	public Constructors(int a, int b) {
		
		int c = a+b;
				
		System.out.println("Addition of a + b is : " + c);
		
	}
	
	public Constructors(String str) {
		System.out.println("String values is : " + str);
		
		
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Constructors c = new Constructors("Hello");
		
		
			

	}

}
