package corejava;

public class Childclass extends ParentClass {

	
	public Childclass() {
		//super();
		System.out.println("Child class contructor");
	}
	
	
	String name ="Cognizant";
	
	public void getData() {
		super.getData();
		System.out.println("child class getdata method");
	}
	
	
	public void getName() {
		System.out.println(name);
		System.out.println(super.name);
	}
	
	
	public void audiosystem() {
		System.out.println("Child class audio system");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Childclass c = new Childclass();
		/*
		c.engine();
		c.brakes();
		c.audiosystem();
		
		c.getName();
		
		System.out.println("--------------------------------------------------------------");
		
		c.getData();
		
		*/
		
		

	}

}
