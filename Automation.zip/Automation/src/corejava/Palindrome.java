package corejava;

public class Palindrome {

	/*
	 * //Algorithm Get string value
	 * get string length
	 * get string char at last
	 * put in null string
	 * concatenate it in for loop , keep on adding last char
	 */

	public void reverseString(String str) {
		
		String revstr="";
		int length = str.length();
		
		for (int i =length-1;i>=0;i--) {
			//System.out.println(str.charAt(i));
			revstr =revstr +str.charAt(i);
		}
		
		if (revstr.equalsIgnoreCase(str)) {
			System.out.println(str + " string is palindrome. Reverse string value is " + revstr);
		}
		
		else {
			System.out.println(str + " string is not palindrome since reverse string value is " + revstr);
			
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Palindrome p = new Palindrome();
		
		p.reverseString("suraj");
		p.reverseString("Madam");
		

	}

}
