package corejava;

public class IndianTraffic implements CentralTraffic, GlobalTraffic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	/*
		IndianTraffic at = new IndianTraffic();
		at.redStop();
		at.yellowSlow();
		at.greenGo();
		System.out.println(at.age);	
	*/
		
		System.out.println("----------------------Central Traffic------------------------------------------------");
		
		CentralTraffic ct = new IndianTraffic();
	ct.redStop();
	ct.yellowSlow();
	ct.greenGo();
	System.out.println(ct.age);	

		
	System.out.println("----------------------Global Traffic------------------------------------------------");
	GlobalTraffic gt = new IndianTraffic();
	gt.globalRules();
	
	System.out.println("----------------------------------------------------------------------");	
	}

	@Override
	public void greenGo() {
		// TODO Auto-generated method stub
System.out.println("Proceed Vehicle");
		
	}

	@Override
	public void yellowSlow() {
		// TODO Auto-generated method stub
		
		System.out.println("Slow Down vehicle");
		
	}

	@Override
	public void redStop() {
		// TODO Auto-generated method stub
		
		System.out.println("Stop vehicle");
		
		
	}

	@Override
	public void globalRules() {
		// TODO Auto-generated method stub
		
		System.out.println("Global Traffic Rules");
		
	}

}
