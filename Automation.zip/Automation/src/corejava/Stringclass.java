package corejava;

public class Stringclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String a = "Hello";
		
		String aa = "Hello"; //no new object creation , Hello is mapped to aa
		
		String aaa = new String("Hello"); //Though Hello already exists stil again new object aaa is created
		
		String b = "Hello";
		
		String bbb = new String("Hello");
		
		String s = " javatraining";
		
		System.out.println(s.charAt(2));
		System.out.println(s.indexOf("t"));
		System.out.println(s.substring(3, 9));
		System.out.println(s.substring(5));
		System.out.println(s.concat(" class"));	
		System.out.println(s.trim());
		System.out.println(s.toUpperCase());
		System.out.println(s.toLowerCase());
		
		String str[]=s.split("t");
		System.out.println(str[0]);
		System.out.println(str[1]);
		
		System.out.println(s.replace("training", "classes"));
		
		
	}

}
