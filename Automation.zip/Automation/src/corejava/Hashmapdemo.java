package corejava;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Hashmapdemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		HashMap<Integer, String> hm = new HashMap<Integer, String>();
		
		hm.put(0, "India");
		hm.put(1, "USA");
		hm.put(2, "UK");
		hm.put(5, "Italy");
		//hm.put(5, "France");
	
		//System.out.println(hm.get(5));
		
		Set sn = hm.entrySet();
		
		Iterator it = sn.iterator();
		
		//System.out.println(it.next());
		//System.out.println(it.next());
		
		while(it.hasNext()) {
			
			Map.Entry mp = (Map.Entry)it.next();			
			System.out.println(mp.getKey());
			System.out.println(mp.getValue());
			
		}
		
		
		

	}

}

//Hashmap is not synchronised and thred safe , concurrent threads accesing hashmap
//Hashtable is thread safe , only one thread is aloowed for operation thhen other

//Hashmap allows to store null values , Hash table does not

//Iterator cannot be used on Hashtable, Enumerator needs to be used



