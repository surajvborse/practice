package corejava;

public interface CentralTraffic {
	
	int age=5;
	public void greenGo();
	public void yellowSlow();
	public void redStop();
	
	
}
