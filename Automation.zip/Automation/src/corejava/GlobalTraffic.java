package corejava;

public interface GlobalTraffic {
	
	public void globalRules();
	

}
