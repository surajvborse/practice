package abstraction;

public abstract class ParentAircraft {
	
	
	public void engineGuidiles() {
		System.out.println("Follow engine guidelines");
	}
	
	
	public void safetyGuidelines() {
		System.out.println("Follow safety guidelines");
	}
	
	
	public abstract void bodyColor();
	
	

}
