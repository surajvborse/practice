package abstraction;

public class ChildAircraft extends ParentAircraft {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ChildAircraft c1= new ChildAircraft();
					
		c1.engineGuidiles();
		
		c1.safetyGuidelines();
		
		c1.bodyColor();

	}

	@Override
	public void bodyColor() {
		// TODO Auto-generated method stub
		
		System.out.println("Body color should be blue");
		
	}

}
